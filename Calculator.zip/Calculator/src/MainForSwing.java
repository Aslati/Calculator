public class MainForSwing {
    public static void main(String[] args) {
        View view = new View();
        view.view();

    }
}
